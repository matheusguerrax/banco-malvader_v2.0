import mysql from "mysql2/promise"

const dbConfig = {
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "1234",
  database: process.env.DB_NAME || "banco_malvader",
  port: Number.parseInt(process.env.DB_PORT || "3306"),
  timezone: "+00:00",
  dateStrings: true,
}

export async function getConnection() {
  try {
    const connection = await mysql.createConnection(dbConfig)
    return connection
  } catch (error) {
    console.error("Erro ao conectar com o banco de dados:", error)
    throw error
  }
}

export async function executeQuery(query: string, params: any[] = []) {
  const connection = await getConnection()
  try {
    const [results] = await connection.execute(query, params)
    return results
  } catch (error) {
    console.error("Erro ao executar query:", error)
    throw error
  } finally {
    await connection.end()
  }
}

export async function callProcedure(procedureName: string, params: any[] = []) {
  const connection = await getConnection()
  try {
    const placeholders = params.map(() => "?").join(", ")
    const query = `CALL ${procedureName}(${placeholders})`
    const [results] = await connection.execute(query, params)
    return results
  } catch (error) {
    console.error("Erro ao executar procedure:", error)
    throw error
  } finally {
    await connection.end()
  }
}
