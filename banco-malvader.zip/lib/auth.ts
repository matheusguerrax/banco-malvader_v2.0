import { executeQuery } from "./database"
import crypto from "crypto"

export interface User {
  id_usuario: number
  nome: string
  cpf: string
  tipo_usuario: "FUNCIONARIO" | "CLIENTE"
  otp_ativo?: string
  otp_expiracao?: string
}

export async function authenticateUser(cpf: string, senha: string): Promise<User | null> {
  try {
    const senhaHash = crypto.createHash("md5").update(senha).digest("hex")

    const users = (await executeQuery("SELECT * FROM usuario WHERE cpf = ? AND senha_hash = ?", [
      cpf,
      senhaHash,
    ])) as User[]

    if (users.length === 0) {
      return null
    }

    const user = users[0]

    // Registrar tentativa de login na auditoria
    await executeQuery("INSERT INTO auditoria (id_usuario, acao, detalhes) VALUES (?, ?, ?)", [
      user.id_usuario,
      "LOGIN_ATTEMPT",
      `Login realizado para CPF: ${cpf}`,
    ])

    return user
  } catch (error) {
    console.error("Erro na autenticação:", error)
    return null
  }
}

export async function generateOTP(userId: number): Promise<string> {
  try {
    // Gerar OTP manualmente já que a procedure pode ter problemas
    const otp = Math.floor(100000 + Math.random() * 900000).toString()

    // Atualizar diretamente no banco
    await executeQuery(
      "UPDATE usuario SET otp_ativo = ?, otp_expiracao = DATE_ADD(NOW(), INTERVAL 5 MINUTE) WHERE id_usuario = ?",
      [otp, userId],
    )

    return otp
  } catch (error) {
    console.error("Erro ao gerar OTP:", error)
    throw error
  }
}

export async function validateOTP(userId: number, otp: string): Promise<boolean> {
  try {
    const users = (await executeQuery("SELECT otp_ativo, otp_expiracao FROM usuario WHERE id_usuario = ?", [
      userId,
    ])) as any[]

    if (users.length === 0) return false

    const user = users[0]
    const now = new Date()
    const expiration = new Date(user.otp_expiracao)

    const isValid = user.otp_ativo === otp && now <= expiration

    if (isValid) {
      // Limpar OTP após uso
      await executeQuery("UPDATE usuario SET otp_ativo = NULL, otp_expiracao = NULL WHERE id_usuario = ?", [userId])
    }

    return isValid
  } catch (error) {
    console.error("Erro ao validar OTP:", error)
    return false
  }
}
