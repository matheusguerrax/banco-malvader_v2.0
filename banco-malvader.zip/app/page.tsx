"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Building2, Users, LogOut } from "lucide-react"

export default function LoginPage() {
  const [userType, setUserType] = useState<"FUNCIONARIO" | "CLIENTE" | "">("")
  const [cpf, setCpf] = useState("")
  const [senha, setSenha] = useState("")
  const [otp, setOtp] = useState("")
  const [showOTP, setShowOTP] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [user, setUser] = useState<any>(null)

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    return numbers.slice(0, 11)
  }

  const handleLogin = async () => {
    if (!userType || !cpf || !senha) {
      setError("Preencha todos os campos obrigatórios")
      return
    }

    if (cpf.length !== 11) {
      setError("CPF deve ter 11 dígitos")
      return
    }

    setLoading(true)
    setError("")

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cpf, senha, tipo_usuario: userType }),
      })

      const data = await response.json()

      if (data.success) {
        setUser(data.user)
        setShowOTP(true)
        // Mostrar OTP para desenvolvimento (em produção seria enviado por SMS/email)
        alert(`Código OTP gerado: ${data.otp}`)
      } else {
        setError(data.message || "Erro na autenticação")
      }
    } catch (error) {
      setError("Erro de conexão com o servidor")
    } finally {
      setLoading(false)
    }
  }

  const handleOTPValidation = async () => {
    if (!otp) {
      setError("Digite o código OTP")
      return
    }

    if (otp.length !== 6) {
      setError("OTP deve ter 6 dígitos")
      return
    }

    setLoading(true)
    setError("")

    try {
      const response = await fetch("/api/auth/validate-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id_usuario, otp }),
      })

      const data = await response.json()

      if (data.success) {
        // Salvar dados do usuário no localStorage para manter sessão
        localStorage.setItem("user", JSON.stringify(user))

        // Redirecionar para o dashboard apropriado
        if (user.tipo_usuario === "FUNCIONARIO") {
          window.location.href = "/funcionario"
        } else {
          window.location.href = "/cliente"
        }
      } else {
        setError(data.message || "Código OTP inválido")
      }
    } catch (error) {
      setError("Erro de conexão com o servidor")
    } finally {
      setLoading(false)
    }
  }

  const generateNewOTP = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/auth/generate-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id_usuario }),
      })

      const data = await response.json()
      if (data.success) {
        alert(`Novo código OTP: ${data.otp}`)
        setOtp("")
      } else {
        setError("Erro ao gerar novo OTP")
      }
    } catch (error) {
      setError("Erro ao gerar novo OTP")
    } finally {
      setLoading(false)
    }
  }

  const handleBack = () => {
    setShowOTP(false)
    setOtp("")
    setError("")
    setUser(null)
  }

  if (showOTP) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-gray-800">Verificação OTP</CardTitle>
            <CardDescription>
              Digite o código de 6 dígitos para validar seu acesso
              <br />
              <span className="text-sm text-gray-500">Usuário: {user?.nome}</span>
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="otp">Código OTP</Label>
              <Input
                id="otp"
                type="text"
                placeholder="000000"
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                maxLength={6}
                className="text-center text-lg tracking-widest"
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={handleOTPValidation} disabled={loading} className="flex-1">
                {loading ? "Validando..." : "Validar"}
              </Button>
              <Button variant="outline" onClick={generateNewOTP} disabled={loading}>
                Novo OTP
              </Button>
            </div>

            <Button variant="ghost" onClick={handleBack} className="w-full">
              Voltar
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4">
            <Building2 className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">Banco Malvader</CardTitle>
          <CardDescription>Sistema Bancário - Acesso Seguro</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="userType">Tipo de Usuário</Label>
            <Select value={userType} onValueChange={(value: "FUNCIONARIO" | "CLIENTE") => setUserType(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o tipo de usuário" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="FUNCIONARIO">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Funcionário
                  </div>
                </SelectItem>
                <SelectItem value="CLIENTE">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Cliente
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="cpf">CPF</Label>
            <Input
              id="cpf"
              type="text"
              placeholder="00000000000"
              value={cpf}
              onChange={(e) => setCpf(formatCPF(e.target.value))}
              maxLength={11}
            />
            <p className="text-xs text-gray-500">Digite apenas os números do CPF</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="senha">Senha</Label>
            <Input
              id="senha"
              type="password"
              placeholder="Digite sua senha"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={handleLogin} disabled={loading} className="flex-1">
              {loading ? "Entrando..." : "Entrar"}
            </Button>
            <Button variant="outline" className="flex items-center gap-2" onClick={() => window.close()}>
              <LogOut className="w-4 h-4" />
              Sair
            </Button>
          </div>

          <div className="text-center text-sm text-gray-500">
            <p>Credenciais de teste:</p>
            <p>
              <strong>Funcionário:</strong> CPF: 12345678901 | Senha: admin123
            </p>
            <p>
              <strong>Cliente:</strong> CPF: 98765432100 | Senha: cliente123
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
