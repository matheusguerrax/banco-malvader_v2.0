import { type NextRequest, NextResponse } from "next/server"
import { authenticateUser, generateOTP } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const { cpf, senha, tipo_usuario } = await request.json()

    if (!cpf || !senha || !tipo_usuario) {
      return NextResponse.json(
        {
          success: false,
          message: "CPF, senha e tipo de usuário são obrigatórios",
        },
        { status: 400 },
      )
    }

    const user = await authenticateUser(cpf, senha)

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          message: "CPF ou senha inválidos",
        },
        { status: 401 },
      )
    }

    if (user.tipo_usuario !== tipo_usuario) {
      return NextResponse.json(
        {
          success: false,
          message: "Tipo de usuário não corresponde ao cadastro",
        },
        { status: 401 },
      )
    }

    // Gerar OTP
    const otp = await generateOTP(user.id_usuario)

    return NextResponse.json({
      success: true,
      user: {
        id_usuario: user.id_usuario,
        nome: user.nome,
        cpf: user.cpf,
        tipo_usuario: user.tipo_usuario,
      },
      otp, // Em produção, isso seria enviado por SMS/email
    })
  } catch (error) {
    console.error("Erro no login:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}
