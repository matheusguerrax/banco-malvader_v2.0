import { type NextRequest, NextResponse } from "next/server"
import { generateOTP } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const { userId } = await request.json()

    if (!userId) {
      return NextResponse.json(
        {
          success: false,
          message: "ID do usuário é obrigatório",
        },
        { status: 400 },
      )
    }

    const otp = await generateOTP(userId)

    return NextResponse.json({
      success: true,
      otp, // Em produção, isso seria enviado por SMS/email
    })
  } catch (error) {
    console.error("Erro ao gerar OTP:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}
