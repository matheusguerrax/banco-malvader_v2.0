import { type NextRequest, NextResponse } from "next/server"
import { validateOTP } from "@/lib/auth"
import { executeQuery } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const { userId, otp } = await request.json()

    if (!userId || !otp) {
      return NextResponse.json(
        {
          success: false,
          message: "ID do usuário e OTP são obrigatórios",
        },
        { status: 400 },
      )
    }

    const isValid = await validateOTP(userId, otp)

    if (!isValid) {
      return NextResponse.json(
        {
          success: false,
          message: "Código OTP inválido ou expirado",
        },
        { status: 401 },
      )
    }

    // Registrar login bem-sucedido na auditoria
    await executeQuery("INSERT INTO auditoria (id_usuario, acao, detalhes) VALUES (?, ?, ?)", [
      userId,
      "LOGIN_SUCCESS",
      "Login realizado com sucesso via OTP",
    ])

    return NextResponse.json({
      success: true,
      message: "Login realizado com sucesso",
    })
  } catch (error) {
    console.error("Erro na validação OTP:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}
