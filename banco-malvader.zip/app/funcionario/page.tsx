"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { UserPlus, Search, Edit, FileText, Users, LogOut, CreditCard, UserCheck, BarChart3 } from "lucide-react"

export default function FuncionarioPage() {
  const [user, setUser] = useState<any>(null)
  const [activeSection, setActiveSection] = useState<string>("")

  useEffect(() => {
    // Verificar se o usuário está logado
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.tipo_usuario !== "FUNCIONARIO") {
        window.location.href = "/"
        return
      }
      setUser(parsedUser)
    } else {
      window.location.href = "/"
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("user")
    window.location.href = "/"
  }

  const menuItems = [
    {
      id: "abertura-conta",
      title: "Abertura de Conta",
      description: "Abrir nova conta para cliente",
      icon: <CreditCard className="w-6 h-6" />,
      color: "bg-green-500",
    },
    {
      id: "encerramento-conta",
      title: "Encerramento de Conta",
      description: "Encerrar conta existente",
      icon: <UserCheck className="w-6 h-6" />,
      color: "bg-red-500",
    },
    {
      id: "consulta-dados",
      title: "Consulta de Dados",
      description: "Consultar informações de contas, clientes e funcionários",
      icon: <Search className="w-6 h-6" />,
      color: "bg-blue-500",
    },
    {
      id: "alteracao-dados",
      title: "Alteração de Dados",
      description: "Alterar dados de contas, clientes e funcionários",
      icon: <Edit className="w-6 h-6" />,
      color: "bg-yellow-500",
    },
    {
      id: "cadastro-funcionarios",
      title: "Cadastro de Funcionários",
      description: "Cadastrar novos funcionários",
      icon: <UserPlus className="w-6 h-6" />,
      color: "bg-purple-500",
    },
    {
      id: "relatorios",
      title: "Geração de Relatórios",
      description: "Gerar relatórios financeiros e operacionais",
      icon: <BarChart3 className="w-6 h-6" />,
      color: "bg-indigo-500",
    },
  ]

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg font-medium text-gray-700">Carregando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Banco Malvader</h1>
                <p className="text-sm text-gray-600">Painel do Funcionário</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{user.nome}</p>
                <p className="text-xs text-gray-500">CPF: {user.cpf}</p>
              </div>
              <Badge variant="secondary" className="px-3 py-1">
                <Users className="w-4 h-4 mr-1" />
                Funcionário
              </Badge>
              <Button variant="outline" size="sm" className="flex items-center gap-2" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Menu Principal</h2>
          <p className="text-gray-600">Selecione uma opção para continuar</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {menuItems.map((item) => (
            <Card
              key={item.id}
              className="hover:shadow-lg transition-shadow cursor-pointer group"
              onClick={() => setActiveSection(item.id)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 ${item.color} rounded-lg flex items-center justify-center text-white group-hover:scale-110 transition-transform`}
                  >
                    {item.icon}
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg">{item.title}</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-sm">{item.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Status Cards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Contas Ativas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">1,234</div>
              <p className="text-xs text-gray-500 mt-1">+12% este mês</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Transações Hoje</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">567</div>
              <p className="text-xs text-gray-500 mt-1">+8% vs ontem</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Volume Total</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">R$ 2.4M</div>
              <p className="text-xs text-gray-500 mt-1">+15% este mês</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ações Rápidas</CardTitle>
              <CardDescription>Acesso rápido às funcionalidades mais utilizadas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <Search className="w-4 h-4" />
                  Buscar Cliente
                </Button>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  Nova Conta
                </Button>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Relatório Diário
                </Button>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
