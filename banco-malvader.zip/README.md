# Banco Malvader - Sistema Bancário

Sistema bancário completo desenvolvido em Next.js com MySQL, implementando funcionalidades de autenticação segura, operações financeiras e gerenciamento de contas.

## 🚀 Funcionalidades

### Autenticação
- Login com CPF e senha
- Autenticação de dois fatores (OTP)
- Diferenciação entre funcionários e clientes
- Auditoria de tentativas de login

### Funcionários
- Abertura e encerramento de contas
- Consulta e alteração de dados
- Cadastro de funcionários
- Geração de relatórios
- Dashboard administrativo

### Clientes
- Consulta de saldo e limite
- Depósitos e saques
- Transferências
- Extrato de transações
- Score de crédito

## 🛠️ Tecnologias

- **Frontend**: Next.js 15, React 18, TypeScript
- **Styling**: Tailwind CSS, shadcn/ui
- **Backend**: Next.js API Routes
- **Database**: MySQL 8.x
- **Authentication**: MD5 Hash + OTP

## 📋 Pré-requisitos

- Node.js 18+ 
- MySQL 8.x
- npm ou yarn

## 🔧 Instalação

1. **Clone o repositório**
\`\`\`bash
git clone <repository-url>
cd banco-malvader
\`\`\`

2. **Instale as dependências**
\`\`\`bash
npm install
\`\`\`

3. **Configure o banco de dados**
- Execute o script `scripts/banco_malvader_setup.sql` no MySQL
- Execute o script `scripts/sample_data.sql` para dados de teste

4. **Configure as variáveis de ambiente**
- Copie `.env.local` e ajuste as configurações do MySQL

5. **Execute o projeto**
\`\`\`bash
npm run dev
\`\`\`

## 🔐 Credenciais de Teste

### Funcionário
- **CPF**: 12345678901
- **Senha**: admin123

### Cliente
- **CPF**: 98765432100
- **Senha**: cliente123

## 📁 Estrutura do Projeto

\`\`\`
banco-malvader/
├── app/
│   ├── api/auth/          # Rotas de autenticação
│   ├── cliente/           # Dashboard do cliente
│   ├── funcionario/       # Dashboard do funcionário
│   └── page.tsx           # Página de login
├── components/ui/         # Componentes UI
├── lib/                   # Utilitários e conexão DB
├── scripts/               # Scripts SQL
└── ...
\`\`\`

## 🗄️ Banco de Dados

O sistema utiliza um banco MySQL com:
- 12 tabelas principais
- 3 triggers para validações
- 2 procedures armazenadas
- 2 views para consultas otimizadas
- Índices para performance

## 📊 Funcionalidades Implementadas

- ✅ Sistema de login com OTP
- ✅ Dashboard funcionário e cliente
- ✅ Estrutura completa do banco
- ✅ Interface responsiva
- ✅ Auditoria de ações
- 🔄 Operações financeiras (em desenvolvimento)
- 🔄 Relatórios (em desenvolvimento)

## 🤝 Contribuição

Este é um projeto acadêmico da Universidade Católica de Brasília para demonstrar conceitos de:
- Programação Orientada a Objetos
- Banco de Dados Relacionais
- Desenvolvimento Web Full-Stack
- Segurança em Sistemas Bancários
