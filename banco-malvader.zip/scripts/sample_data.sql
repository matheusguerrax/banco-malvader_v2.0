-- Inserir dados de exemplo para teste

-- Inserir usuários
INSERT INTO usuario (nome, cpf, data_nascimento, telefone, tipo_usuario, senha_hash) VALUES
('João Silva', '12345678901', '1985-05-15', '11999999999', 'FUNCIONARIO', MD5('admin123')),
('Maria Santos', '98765432100', '1990-08-20', '11888888888', 'CLIENTE', MD5('cliente123')),
('Pedro Oliveira', '11122233344', '1988-12-10', '11777777777', 'CLIENTE', MD5('cliente456'));

-- Inserir endereços
INSERT INTO endereco (id_usuario, cep, local, numero_casa, bairro, cidade, estado, complemento) VALUES
(1, '01310-100', 'Av. Paulista', 1000, 'Bela Vista', 'São Paulo', 'SP', 'Sala 101'),
(2, '04038-001', 'Rua das Flores', 123, 'Vila Olímpia', 'São Paulo', 'SP', 'Apto 45'),
(3, '22071-900', 'Av. Copacabana', 456, 'Copacabana', 'Rio de Janeiro', 'RJ', NULL);

-- Inserir funcionário
INSERT INTO funcionario (id_usuario, codigo_funcionario, cargo) VALUES
(1, 'FUNC001', 'GERENTE');

-- Inserir clientes
INSERT INTO cliente (id_usuario, score_credito) VALUES
(2, 75.50),
(3, 82.30);

-- Inserir agência
INSERT INTO agencia (nome, codigo_agencia, endereco_id) VALUES
('Agência Central', '0001', 1);

-- Inserir contas
INSERT INTO conta (numero_conta, id_agencia, saldo, tipo_conta, id_cliente) VALUES
('00001-1', 1, 1500.00, 'CORRENTE', 1),
('00002-2', 1, 2500.00, 'POUPANCA', 2);

-- Inserir conta corrente
INSERT INTO conta_corrente (id_conta, limite, data_vencimento, taxa_manutencao) VALUES
(1, 1000.00, '2024-12-31', 15.00);

-- Inserir conta poupança
INSERT INTO conta_poupanca (id_conta, taxa_rendimento) VALUES
(2, 0.65);
