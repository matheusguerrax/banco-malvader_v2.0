import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Para desenvolvimento, vamos simplificar o middleware
  // Em produção, você deve implementar uma verificação mais robusta

  const { pathname } = request.nextUrl

  // Permitir acesso às rotas de API e arquivos estáticos
  if (
    pathname.startsWith("/api/") ||
    pathname.startsWith("/_next/") ||
    pathname.startsWith("/favicon.ico") ||
    pathname === "/"
  ) {
    return NextResponse.next()
  }

  // Para rotas protegidas, apenas continuar
  // A verificação de autenticação será feita no lado do cliente
  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!api|_next/static|_next/image|favicon.ico).*)",
  ],
}
